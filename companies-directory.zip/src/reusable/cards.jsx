import { Card, Col } from "react-bootstrap";

function CompanyCard({ company }) {

  return (
    <div className="company-card">
      <Col className="col-12" lg={3} md={3} sm={6}>
        <Card className="card custom-card">
          <Card.Header>
            <h3 className="card-title">{company.name}</h3>
            <span className="card-tag">
              {company.industry}
            </span>
          </Card.Header>
          <Card.Body className="card-details">
            <p className="detail-item">
              <svg className="detail-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.828 0l-4.243-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
              {company.location}
            </p>
            <p className="detail-item">
              <svg className="detail-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-3h-5v3z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20h5v-3h-5v3z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 20h5v-3H3v3z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 12h5V9h-5v3z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 12h5V9h-5v3z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12h5V9H3v3z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 4L7 7H4L1 4V1h9v3z"></path></svg>
              {company.employees.toLocaleString()} Employees
            </p>
            <p className="detail-item">
              <svg className="detail-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h.01M17 11h.01M3 15h2m4 0h.01M17 15h2m-4 0h.01M3 19h2m4 0h.01M17 19h2m-4 0h.01M1 19h22v-6c0-1.1.9-2 2-2h-1c-1.1 0-2 .9-2 2v6H1z"></path></svg>
              Founded: {company.founded}
            </p>
          </Card.Body>
        </Card>
      </Col>
    </div>
  )
}
export default CompanyCard;