import { Fragment } from "react";
import { Route, Routes } from "react-router-dom";
import Companies from "./container/companies";

function App () {
    return (
        <Fragment>
          <div className="main-content">
             <Routes>
                <Route path={`${import.meta.env.BASE_URL}/`} index element={<Companies/>}/>
             </Routes>
          </div>
        </Fragment>
    )
}
export default App;