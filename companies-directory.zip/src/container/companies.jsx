import { Fragment, useEffect, useMemo, useState } from "react";
import { Button, Form, Pagination, Row } from "react-bootstrap";
import { CompaniesData } from "../json-data/companiesdata";
import CompanyCard from "../reusable/cards";


function Companies() {

    // State Management
    const [companies, setCompanies] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [filters, setFilters] = useState({ search: '', industry: '', location: '' });

    const COMPANIES_PER_PAGE = 12;

    // data fetching
    const fetchCompaniesFromApi = () => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (Math.random() < 0.1) {
                    reject(new Error("Failed to fetch data due to network timeout."));
                } else {
                    resolve(CompaniesData);
                }
            }, 1500);
        });
    }

    useEffect(() => {
        setLoading(true);
        setError(null);
        fetchCompaniesFromApi()
            .then(data => {
                setCompanies(data);
                setLoading(false);
            })
            .catch(err => {
                console.error("API Fetch Error:", err);
                setError("Could not load company data. Please try refreshing the page.");
                setLoading(false);
            });
    }, []);

    useEffect(() => {
        setCurrentPage(1);
    }, [filters]);

    // Filter Handler
    const handleFilterChange = (e) => {
        const { name, value } = e.target;
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleClearFilters = () => {
        setFilters({ search: '', industry: '', location: '' });
    };

    const uniqueIndustries = useMemo(() => {
        const industries = companies.map(c => c.industry);
        return [...new Set(industries)].sort();
    }, [companies]);

    const uniqueLocations = useMemo(() => {
        const locations = companies.map(c => c.location);
        return [...new Set(locations)].sort();
    }, [companies]);

    const filteredCompanies = useMemo(() => {
        if (!companies.length) return [];
        const lowerSearch = filters.search.toLowerCase();
        return companies.filter(company => {
            const matchesSearch = !lowerSearch ||
                company.name.toLowerCase().includes(lowerSearch) ||
                company.industry.toLowerCase().includes(lowerSearch) ||
                company.location.toLowerCase().includes(lowerSearch);

            const matchesIndustry = !filters.industry || company.industry === filters.industry;
            const matchesLocation = !filters.location || company.location === filters.location;

            return matchesSearch && matchesIndustry && matchesLocation;
        });
    }, [companies, filters]);

    // Pagination
    const totalPages = Math.ceil(filteredCompanies.length / COMPANIES_PER_PAGE);

    const paginatedCompanies = useMemo(() => {
        const startIndex = (currentPage - 1) * COMPANIES_PER_PAGE;
        const endIndex = startIndex + COMPANIES_PER_PAGE;
        return filteredCompanies.slice(startIndex, endIndex);
    }, [filteredCompanies, currentPage]);

    const pages = [];
    const maxPagesToShow = 5;

    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);

    if (endPage - startPage + 1 < maxPagesToShow) {
        startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
    }
    //Loader
    if (loading) {
        return (
            <div className="loader-container">
                <div className="spinner"></div>
            </div>
        );
    }

    const noResults = filteredCompanies.length === 0;

    return (
        <Fragment>
            <h1>Companies Directory</h1>
            <div className="filter-bar">
                <div className="filter-group flex-grow">
                    <Form.Label htmlFor="search" className="filter-label">Search</Form.Label>
                    <Form.Control type="text" id="search" name="search" value={filters.search} onChange={handleFilterChange} placeholder="e.g., AlphaTech, Retail, or City" className="form-input" />
                </div>
                <div className="filter-group filter-select-container">
                    <Form.Label htmlFor="industry" className="filter-label">Filter by Industry</Form.Label>
                    <select id="industry" name="industry" value={filters.industry} onChange={handleFilterChange} className="form-input form-select">
                        <option value="">All Industries</option>
                        {uniqueIndustries.map(ind => (
                            <option key={ind} value={ind}>{ind}</option>
                        ))}
                    </select>
                </div>
                <div className="filter-group filter-select-container">
                    <Form.Label htmlFor="location" className="filter-label">Filter by Location</Form.Label>
                    <select id="location" name="location" value={filters.location} onChange={handleFilterChange} className="form-input form-select">
                        <option value="">All Locations</option>
                        {uniqueLocations.map(loc => (
                            <option key={loc} value={loc}>{loc}</option>
                        ))}
                    </select>
                </div>
                <Button onClick={handleClearFilters} className="clear-button">
                    Clear
                </Button>
            </div>
            <Row>
                <div className="company-grid">
                    {noResults ? (
                        <div className="no-results-message">
                            No companies found matching the current filters.
                        </div>
                    ) : (
                        paginatedCompanies.map(company => (
                            <CompanyCard key={company.id} company={company} />
                        ))
                    )}
                </div>
            </Row>
            {totalPages > 1 && !noResults && (
                <Pagination className="pagination-controls">
                    <Pagination.Prev onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))} disabled={currentPage === 1} />
                    {startPage > 1 && (
                        <>
                            <Pagination.Item onClick={() => setCurrentPage(1)} active={currentPage === 1}>1</Pagination.Item>
                            {startPage > 2 && <Pagination.Ellipsis />}
                        </>
                    )}
                    {pages.map(page => (
                        <Pagination.Item key={page} active={page === currentPage} onClick={() => setCurrentPage(page)}>
                            {page}
                        </Pagination.Item>
                    ))}
                    {endPage < totalPages && (
                        <>
                            {endPage < totalPages - 1 && <Pagination.Ellipsis />}
                            <Pagination.Item onClick={() => setCurrentPage(totalPages)} active={currentPage === totalPages}>
                                {totalPages}
                            </Pagination.Item>
                        </>
                    )}
                    <Pagination.Next onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))} disabled={currentPage === totalPages} />
                </Pagination>
            )}
        </Fragment>
    );
}

export default Companies; 